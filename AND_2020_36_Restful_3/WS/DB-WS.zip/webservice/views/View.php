<?php

/**
 * Clase base para la representación de las vistas
 */
abstract class View {
    public abstract function render($body);
}