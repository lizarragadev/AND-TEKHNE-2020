<?php

 $cleardb_url = parse_url(getenv("CLEARDB_DATABASE_URL"));
 $cleardb_server = $cleardb_url["host"];
 $cleardb_username = $cleardb_url["user"];
 $cleardb_password = $cleardb_url["pass"];
 $cleardb_db = substr($cleardb_url["path"], 1);


define("MYSQL_HOST", $cleardb_server);
define("MYSQL_USERNAME", $cleardb_username);
define("MYSQL_PASSWORD", $cleardb_password);
define("MYSQL_DATABASE_NAME", $cleardb_db);
