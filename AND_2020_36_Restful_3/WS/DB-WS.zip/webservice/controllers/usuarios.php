<?php

require_once 'data/MysqlManager.php';

/**
 * Controlador del recurso "/usuarios"
 */
class usuarios {

    public static function get($urlSegments) {

    }

    public static function post($urlSegments) {

        if (!isset($urlSegments[0])) {
            throw new ApiException(
                400,
                0,
                "El recurso está mal referenciado",
                "http://localhost",
                "El recurso $_SERVER[REQUEST_URI] no esta sujeto a resultados"
            );
        }

        switch ($urlSegments[0]) {
            case "register":
                return self::saveAffiliate();
                break;
            case "login":
                return self::authAffiliate();
                break;
            default:
                throw new ApiException(
                    404,
                    0,
                    "El recurso al que intentas acceder no existe",
                    "http://localhost", "No se encontró el segmento \"usuarios/$urlSegments[0]\".");
        }
    }

    public static function put($urlSegments) {

    }

    public static function delete($urlSegments) {

    }

    private static function saveAffiliate() {
        // Obtener parámetros de la petición
        $parameters = file_get_contents('php://input');
        $decodedParameters = json_decode($parameters, true);

        // Controlar posible error de parsing JSON
        if (json_last_error() != JSON_ERROR_NONE) {
            $internalServerError = new ApiException(
                500,
                0,
                "Error interno en el servidor. Contacte al administrador",
                "http://localhost",
                "Error de parsing JSON. Causa: " . json_last_error_msg());
            throw $internalServerError;
        }

        // Verificar integridad de datos
        // TODO: Implementar restricciones de datos adicionales
        if (!isset($decodedParameters["id"]) ||
            !isset($decodedParameters["password"]) ||
            !isset($decodedParameters["name"]) ||
            !isset($decodedParameters["address"]) ||
            !isset($decodedParameters["gender"])
        ) {
            // TODO: Crear una excepción individual por cada causa anómala
            throw new ApiException(
                400,
                0,
                "Verifique los datos del usuario tengan formato correcto",
                "http://localhost",
                "Uno de los atributos del usuario no está definido en los parámetros");
        }

        // Insertar afiliado
        $dbResult = self::insertAffiliate($decodedParameters);

        // Procesar resultado de la inserción
        if ($dbResult) {
            return ["status" => 201, "message" => "Afiliado registrado"];
        } else {
            throw new ApiException(
                500,
                0,
                "Error del servidor",
                "http://localhost",
                "Error en la base de datos al ejecutar la inserción del usuario.");
        }
    }

    private static function authAffiliate() {

        // Obtener parámetros de la petición
        $parameters = file_get_contents('php://input');
        $decodedParameters = json_decode($parameters, true);

        // Controlar posible error de parsing JSON
        if (json_last_error() != JSON_ERROR_NONE) {
            $internalServerError = new ApiException(
                500,
                0,
                "Error interno en el servidor. Contacte al administrador",
                "http://localhost",
                "Error de parsing JSON. Causa: " . json_last_error_msg());
            throw $internalServerError;
        }

        // Verificar integridad de datos
        if (!isset($decodedParameters["id"]) ||
            !isset($decodedParameters["password"])
        ) {
            throw new ApiException(
                400,
                0,
                "Los datos del usuario deben estar definidas correctamente",
                "http://localhost",
                "El atributo \"id\" o \"password\" o ambos, están vacíos o no definidos"
            );
        }

        $userId = $decodedParameters["id"];
        $password = $decodedParameters["password"];

        // Buscar usuario en la tabla
        $dbResult = self::findAffiliateByCredentials($userId, $password);

        // Procesar resultado de la consulta
        if ($dbResult != NULL) {
            return [
                "status" => 200,
                "id" => $dbResult["id"],
                "name" => $dbResult["name"],
                "address" => $dbResult["address"],
                "gender" => $dbResult["gender"],
                "token" => $dbResult["token"]
            ];
        } else {
            throw new ApiException(
                400,
                0,
                "Usuario o contraseña inválidos",
                "http://localhost",
                "Puede que no exista un usuario creado con el usuario \"$userId\" o que la contraseña \"$password\" sea incorrecta."
            );
        }
    }

    private static function insertAffiliate($decodedParameters) {
        //Extraer datos del afiliado
        $id = $decodedParameters["id"];
        $password = $decodedParameters["password"];
        $name = $decodedParameters["name"];
        $address = $decodedParameters["address"];
        $gender = $decodedParameters["gender"];

        // Encriptar contraseña
        $hashPassword = password_hash($password, PASSWORD_DEFAULT);

        // Generar token
        $token = uniqid(rand(), TRUE);

        try {
            $pdo = MysqlManager::get()->getDb();

            // Componer sentencia INSERT
            $sentence = "INSERT INTO persona (id, hash_password, name, address, gender, token)" .
                " VALUES (?,?,?,?,?,?)";

            // Preparar sentencia
            $preparedStament = $pdo->prepare($sentence);
            $preparedStament->bindParam(1, $id);
            $preparedStament->bindParam(2, $hashPassword);
            $preparedStament->bindParam(3, $name);
            $preparedStament->bindParam(4, $address);
            $preparedStament->bindParam(5, $gender);
            $preparedStament->bindParam(6, $token);

            // Ejecutar sentencia
            return $preparedStament->execute();

        } catch (PDOException $e) {
            throw new ApiException(
                500,
                0,
                "Error de base de datos en el servidor",
                "http://localhost",
                "Ocurrió el siguiente error al intentar insertar el usuario: " . $e->getMessage());
        }
    }

    private static function findAffiliateByCredentials($userId, $password) {
        try {
            $pdo = MysqlManager::get()->getDb();

            // Componer sentencia SELECT
            $sentence = "SELECT * FROM persona WHERE id=?";

            // Preparar sentencia
            $preparedSentence = $pdo->prepare($sentence);
            $preparedSentence->bindParam(1, $userId, PDO::PARAM_STR);

            // Ejecutar sentencia
            if ($preparedSentence->execute()) {
                $affiliateData = $preparedSentence->fetch(PDO::FETCH_ASSOC);

                // Verificar contraseña
                if (password_verify($password, $affiliateData["hash_password"])) {
                    return $affiliateData;
                } else {
                    return null;
                }

            } else {
                throw new ApiException(
                    500,
                    0,
                    "Error de base de datos en el servidor",
                    "http://localhost",
                    "Hubo un error ejecutando una sentencia SQL en la base de datos. Detalles:" . $pdo->errorInfo()[2]
                );
            }

        } catch (PDOException $e) {
            throw new ApiException(
                500,
                0,
                "Error de base de datos en el servidor",
                "http://localhost",
                "Ocurrió el siguiente error al consultar el usuario: " . $e->getMessage());
        }
    }

}
